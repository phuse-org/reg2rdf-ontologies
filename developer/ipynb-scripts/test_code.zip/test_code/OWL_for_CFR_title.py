# code for generating the CFR classes:
#	
#    <!-- http://sharepoint.fda.gov/orgs/CDER-OTS/CDER-Ontologies/Oreg/OREG_0000060 -->
#
#    <owl:Class rdf:about="&Oreg;OREG_0000060">
#        <rdfs:label xml:lang="en">3 CFR</rdfs:label>
#        <rdfs:subClassOf rdf:resource="&Oreg;OREG_0000025"/>
#    </owl:Class>

updateFile = open('CFR_title_OWL', 'w')

for i in range(4,51):
  if i == 21:
    pass
  else:
    j = i+57
    j = str(j)
    string_var = "0"*(7-len(j))
    id = string_var + j	
    updateFile.write("    <!-- http://sharepoint.fda.gov/orgs/CDER-OTS/CDER-Ontologies/Oreg/OREG_"+id+" -->\n\n")
    updateFile.write("    <owl:Class rdf:about=\"&Oreg;OREG_"+id+"\">\n")
    updateFile.write("        <rdfs:label xml:lang=\"en\">"+str(i)+" CFR</rdfs:label>\n")
    updateFile.write("        <rdfs:subClassOf rdf:resource=\"&Oreg;OREG_0000025\"/>\n")
    updateFile.write("    </owl:Class>\n\n")

updateFile.close()