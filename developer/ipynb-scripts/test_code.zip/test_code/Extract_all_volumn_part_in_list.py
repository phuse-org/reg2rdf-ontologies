
# coding: utf-8

# In[7]:

# get all the volumn and part, save it to a list --> then import for extract all sectno, subject in all parts.
import re
from xml.etree.cElementTree import ElementTree

#updateFile = open("CFR-2015-title21-vol-chap.csv",'w')
#updateFile.write("\"volumn\",\"chap\"\n")
part_list = []

for i in range(1,10):
    vol = str(i)
    file = "C:/Users/Yu.Lin/python codes/CFR/title-21/CFR-2015-title21-vol"+str(vol)+".xml"
    tree = ElementTree()
    tree.parse(file)
    root = tree.getroot()
    root.findall(".")


    for PART in root.iter('PART'):
        if PART.find('EAR') is not None:
            EAR = PART.find('EAR').text
            EAR = re.sub("[^0123456789]","",EAR)
            part_list.append([vol,EAR])

