"""
 This code is used to extract the text from CFR XML 'SUBPART' tag. And save all inside the 'SUBPART' tag into a seperate file
"""
import xml.etree.ElementTree as ET
tree = ET.parse('CFR-2015-title21-part11.xml')
root = tree.getroot()

# Top-level elements
root.findall(".")
print root.tag
print root.attrib
for child in root:
print child.tag, child.attrib
for SUBPART in root.iter('SUBPART'):
print SUBPART.tag
p = root.find("./SUBPART/SECTION/p")
print p

# http://stackoverflow.com/questions/9821143/html-parsing-using-python
""""
from HTMLParser import HTMLParser
class MyHTMLParser(HTMLParser):
def handle_data(self, data):
print "Data :", data
f=open("CFR-2015-title21-part11.xml","r")
s=f.read()
parser = MyHTMLParser()
parser.feed(s)
"""

#http://stackoverflow.com/questions/4624062/get-all-text-inside-a-tag-in-lxml
from lxml import etree
data = open('CFR-2015-title21-part11.xml','r').read()
tree = etree.HTML(data)
text = tree.xpath("//p/text()")
updateFile = open('CFR21_part11.txt', 'w')
updateFile.write(str(text))
updateFile.close()