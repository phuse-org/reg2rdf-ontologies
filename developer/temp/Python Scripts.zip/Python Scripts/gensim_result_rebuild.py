# This file transform the gensim result as csv files

import csv,re,os

filename=os.environ['INPUT'] 
file = "/home/yu.lin/21CFR/output/gensim_LDA_out/"+filename

csv_filename = filename.replace('txt','csv')

csv_filepath = "/home/yu.lin/21CFR/output/gensim_LDA_out_csv/"+csv_filename
csv_file = open(csv_filepath,'wb')
csv_writer = csv.writer(csv_file)
csv_writer.writerow( ('TopicNo', 'Topic Words', 'Probability Score') )
with open(file) as f:
    topics = dict()
    topics_1 = dict()
    topics_sort = dict()
    topics_sorted =dict()
    text = f.read()
    texts = text.split('----')
    topic_pattern = re.compile("(.*:)")
    for topic in texts:
        topic = topic.strip()
        if len(topic)<>0:
            topics_key = topic_pattern.findall(topic)
            topics_key = ''.join(topics_key)
            #print topics_key
            topics_value = topic.replace(topics_key,'')
            
            pattern = re.compile("(\(.*\))")
            topics_value_list = pattern.findall(topics_value)

            topics_value_text = ''.join(topics_value_list)
            topics_1[topics_key] = topics_value_text
            topics_value_text_list = topics_value_text.split("), (")
            i = 0
            for each_pair in topics_value_text_list:
                i = i+1
                each_pair = each_pair.replace("(","")
                each_pair = each_pair.replace(")","")
                each_pair_list = each_pair.split(",")
                topic_word = each_pair_list[0]
                if i == 1: 
                    measure_first = each_pair_list[1]
                    topics[topics_key] = measure_first
                    topics_sort[topics_key] = float(measure_first)
  
#    print topics_1             
                      
       # topics_sort is a key:value pair made of topicsNo and the first probability score.
        #topics_measure_first_sorted is reversed sorted topics_sort by probability score.
                
    topics_measure_first_sorted = sorted(topics_sort.items(), key=lambda x: x[1],reverse=True)
        
    print topics_measure_first_sorted
        #topics_sorted is reordered topics dictionary, where the order of key sorted by the first word probability score in topics_meaure_first_sorted
    for j in topics_measure_first_sorted:
        #print j
        key_s = j[0]
#        print key_s
        key_s_f = key_s.replace(":",'')
        each_value_list = topics_1[key_s]
        topics_value_text = ''.join(each_value_list)
        topics_value_text_list = topics_value_text.split("), (")
        for each_tv_pair in topics_value_text_list:
            each_tv_pair = each_tv_pair.replace("(","")
            each_tv_pair = each_tv_pair.replace(")","")
            each_tv_pair_list = each_tv_pair.split(",")
            topic_word = each_tv_pair_list[0]
            measure_s = each_tv_pair_list[1]
            csv_writer.writerow((key_s_f,topic_word,measure_s))
    csv_file.close()
        



        
            