import pickle
import re,nltk
import csv

from nltk.stem import WordNetLemmatizer
wnl = WordNetLemmatizer()

stoplist = set(nltk.corpus.stopwords.words("stopwords_CFR")) 

# read definition file:
def_file = "/home/yu.lin/21CFR/output/11_201.txt"
def_word_bag = []
with open(def_file) as d_f:    
    for line in d_f:
        words_def = line.strip().split()
        for word_def in words_def:
            if (word_def not in stoplist):
                if (word_def.endswith(('ed','ing')) and word_def <> 'labeling'):
                    word_def = wnl.lemmatize(word_def,'v')
                else:
                    word_def = wnl.lemmatize(word_def)
                if word_def not in def_word_bag:
                    def_word_bag.append(word_def)

print len(def_word_bag)

with open("/home/yu.lin/21CFR/output/def_word_bag_list.txt", "wb") as myFile_d:
#/dev/shm/myKeyPhraseDict.txt
    pickle.dump(def_word_bag, myFile_d)
    
# read title word bag file    
title_word_bag_file = "/home/yu.lin/21CFR/logfile/titlewordbagfile.txt"
title_word_bag = []
with open(title_word_bag_file) as t_f:
    for line in t_f:
        word_title = line.strip().split(',')
        for each in word_title:
            if each not in title_word_bag:
                title_word_bag.append(each)

print len(title_word_bag)

with open("/home/yu.lin/21CFR/output/title_word_bag_list.txt", "wb") as myFile_t:
#/dev/shm/myKeyPhraseDict.txt
    pickle.dump(def_word_bag, myFile_t)
    
    


    