#sge_par.sh
#CFR_RAKE_key.lst

import pickle,nltk,re,doxc
from docx import Document

from nltk.stem import WordNetLemmatizer
wnl = WordNetLemmatizer()

stoplist = set(nltk.corpus.stopwords.words("stopwords_CFR")) 

with open("/home/yu.lin/21CFR/output/title_dict.txt", "rb") as myFile_t:
    title_dict = pickle.load(myFile_t)
    
with open("/home/yu.lin/21CFR/output/title_word_bag_list.txt", "rb") as myFile_tw:
    title_word_bag = pickle.load(myFile_tw)

with open("/home/yu.lin/21CFR/output/def_word_bag_list.txt", "rb") as myFile_dw:
    def_word_bag = pickle.load(myFile_dw)


def format(value):
    return "%.5f" % value
    
filename=os.environ['INPUT']
sectionNo = filename.replace(".key","")
title = title_dict[sectionNo]

with open("/home/yu.lin/21CFR/output//Gensim_score_list/"+sectionNo+"_gensim_score_dict.txt", "rb") as myFile_gs:
    Gensim_score = pickle.load(myFile_gs)
    
document = Document()
document_filename = "/home/yu.lin/21CFR/output/final_key_doc/"+sectionNO+".final_key.docx"
heading = "Section: "+sectionNo+" "+title.encode("ascii","ignore")
document.add_heading(heading, level=1)
link = "https://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfcfr/CFRSearch.cfm?fr="+sectionNo
document.add_paragraph(link)

RAKE_file = "/home/yu.lin/21CFR/output/CFR_keywords_RAKE/"+filename
with open(RAKE_file) as f:
    all_list = dict()
    for line in f:
        score_set = line.strip().split(",")
        words = score_set[0]
        words = words.decode('utf-8')
        words_set = words.split()
        stem_words_set = []
        score = float(score_set[1])
        
        # match in the Gensim_score dict
        gensim_score_total = 0
        def_score_total = 0
        title_score_total = 0
        final_score = 0
        
        if len(words_set) > 1:
            for eachword in words_set:
                if (eachword.endswith(('ed','ing')) and eachword <> 'labeling'):
                    eachword = wnl.lemmatize(eachword,'v')
                else:
                    eachword = wnl.lemmatize(eachword)
                stem_words_set.append(eachword)
                                                  
                if eachword in Gensim_score:
                    gensim_score = Gensim_score[eachword] 
                    gensim_score_total += gensim_score
                    
                if eachword in def_word_bag:
                    def_score = 1
                    def_score_total +=def_score
                
                if eachword in title_word_bag:
                    title_score = 1
                    title_score_total +=title_score
                
            stem_phrase = " ".join(stem_words_set)
            gensim_score_1 = 0
            if stem_phrase in Gensim_score:
                gensim_score_1 = float(Gensim_score[stem_phrase])*1000*len(stem_words_set)
            gensim_score_total +=gensim_score_1
            
            final_score = gensim_score_total+def_score_total+title_score_total+score
            
            all_list[stem_phrase] = final_score
            
        all_list_sorted = sorted(all_list.items(), key=lambda x: x[1],reverse=True)
        
        p = document.add_paragraph()
        p.add_run("key phrase candidates:\n").bold = True
        
        for k in range(0,len(all_list_sorted)):
            line = all_list_sorted[k]
            #line = str(line)
            phrase = line[0]
            phrase = phrase.encode('ascii',"ignore")
            phrase_clean = re.sub(u'[^\u0020-\uD7FF\u0009\u000A\u000D\uE000-\uFFFD\u10000-\u10FFFF]+', '', phrase)
            #print phrase_clean
            p.add_run(phrase_clean).font.name = "Calibri"
            p.add_run(' , ').font.name = "Calibri"
            score = str(format(line[1]))
            score = score.encode('utf-8')
            p.add_run(score).font.name = "Calibri"
            p.add_run('\n')
            
                    
    document.save(document_filename)