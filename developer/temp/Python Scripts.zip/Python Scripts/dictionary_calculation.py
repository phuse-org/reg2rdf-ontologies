# this file calculate the dictionary length
# run sge.sh


import os,re
from gensim import corpora, models, similarities

# resue the dictionary
dictionary = corpora.Dictionary.load('/home/yu.lin/21CFR/runs/gensim_tmp/dictionary/21CFR_2wp_dict.dict')
print(dictionary)