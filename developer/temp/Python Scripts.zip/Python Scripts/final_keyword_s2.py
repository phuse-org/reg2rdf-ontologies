# parallel computing
import glob, os, re, csv, pickle

from collections import defaultdict

Gensim_score = dict()

Gensim_scores_list = dict()

filename=os.environ['INPUT'] 
Gensim_file = "/home/yu.lin/21CFR/output/gensim_LDA_out_csv/"+filename
sectionNo = filename.replace(".csv","")
with open(Gensim_file) as g_f:
    reader = csv.DictReader(g_f)
    d1 = defaultdict(list)
    for row in reader:
        key_phrase = row["Topic Words"]
        key_phrase = key_phrase.replace("_", " ")
        score = row["Probability Score"]
        d1[key_phrase].append(score)
        # to avoid the overwrite of same key_phrase in gensim score list, it is sorted reversely, so if overwrites, the final score will be a smallest score.
        Gensim_scores_list = dict((key_phrase, tuple(score)) for key_phrase, score in d1.iteritems())
        
    for eachkey in Gensim_scores_list:
        Total_value = 0
        value_list = Gensim_scores_list[eachkey]
        for value in value_list:
            Total_value = Total_value+float(value)
            Gensim_score[eachkey]=Total_value
        
print len(Gensim_score)

with open("/home/yu.lin/21CFR/output/Gensim_score_list/"+sectionNo+"_gensim_score_dict.txt", "wb") as myFile_g:
#/dev/shm/myKeyPhraseDict.txt
    pickle.dump(Gensim_score, myFile_g)