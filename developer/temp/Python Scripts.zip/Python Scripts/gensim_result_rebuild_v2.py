# This file transform the gensim result as csv files

# load the phrase dictionary and switch the key and value

import pickle
import csv,re,os

with open("/home/yu.lin/21CFR/output/myKeyPhraseDict.txt", "rb") as myFile:
    key_phrase_dict = pickle.load(myFile)
    
key_dict_for_result = {y:x for x,y in key_phrase_dict.iteritems()}

filename=os.environ['INPUT'] 
file = "/home/yu.lin/21CFR/output/gensim_LDA_out/"+filename

csv_filename = filename.replace('txt','csv')

csv_filepath = "/home/yu.lin/21CFR/output/gensim_LDA_out_csv/"+csv_filename
csv_file = open(csv_filepath,'wb')
csv_writer = csv.writer(csv_file)
csv_writer.writerow( ('TopicNo', 'Topic Words', 'Probability Score') )
with open(file) as f:
    topics = dict()
    topics_sort = dict()
    topics_sorted =dict()
    text = f.read()
    texts = text.split('----')
    topic_pattern = re.compile("(.*:)")
    for topic in texts:
        topic = topic.strip()
        if len(topic)<>0:
            topics_key = topic_pattern.findall(topic)
            topics_key = ''.join(topics_key)
            #print topics_key
            pattern = re.compile("(\[.*\])")
            topics_value_list = pattern.findall(topic)
            print topics_value_list
            topics[topics_key] = topics_value_list

                
            measure_first_list = topics_value_list[0]
            print measure_first_list
            measure_first = measure_first_list[1]
            measure_first = re.sub("\[|\]",'',measure_first)
            topics_sort[topics_key] = float(measure_first)
           
       # topics_sort is a key:value pair made of topicsNo and the first probability score.
        #topics_measure_first_sorted is reversed sorted topics_sort by probability score.
                
    topics_measure_first_sorted = sorted(topics_sort.items(), key=lambda x: x[1],reverse=True)
        
        #topics_sorted is reordered topics dictionary, where the order of key sorted by the first word probability score in topics_meaure_first_sorted
    for i in topics_measure_first_sorted:
        #print i
        key_s = i[0]
        topics_sorted[key_s] = topics[key_s]
        key_s_f = re.sub(":",'',key_s)
        for j in topics[key_s]:
            word_s = j[0]
                #print word_s
            measure_s = j[1]
            measure_s = re.sub("\[|\]",'',measure_s)
            #for k in key_dict_for_result.keys():
                #if re.search(k,word_s):
                       # word_s = word_s.replace(k,key_dict_for_result[k])
            csv_writer.writerow((key_s_f,word_s,measure_s))
    csv_file.close()
        



        
            