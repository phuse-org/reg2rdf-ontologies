# sge.sh


import pickle

import glob, os, re
import csv

def input_all_files(DIR,filetype):
    
    files = []
    filename = "*."+filetype
    for file in glob.glob(os.path.join(DIR, filename)):
         files.append(file)
    return files

title_dict = dict()

DIR = "/home/yu.lin/21CFR/output/part_sect/test1"
filetype = "csv"

title_files = input_all_files(DIR,filetype)

for title_file in title_files:
    with open(title_file) as t_f:
        for line in t_f.readlines():
            line = line.strip()
            lineset = line.split(",")
            #print lineset
            section =lineset[0].replace("\"","")
            title = lineset[1].replace("\"","")
            title_dict[section]=title


with open("/home/yu.lin/21CFR/output/title_dict.txt", "wb") as myFile_t:
#/dev/shm/myKeyPhraseDict.txt
    pickle.dump(title_dict, myFile_t)
    
    


    