#$ -cwd
#$ -S /bin/sh
#$ -o sysout
#$ -l h_vmem=2G
#$ -l h_rt=000:10:00
#$ -j y
#$ -N final_keyword_s1_1

#$ -pe thread 1
#$ -t  1-1

echo "Running task $JOB_NAME (ID of $JOB_ID) on $HOSTNAME"

export PATH=/projects/mikem/python/bin:$PATH 
export LD_LIBRARY_PATH=/projects/mikem/python/lib:$LD_LIBRARY_PATH 
export PYTHONPATH=/projects/mikem/python:$PYTHONPATH 
export PYTHONPATH=/projects/mikem/python/lib/python2.7:$PYTHONPATH 
export PYTHONPATH=/projects/mikem/python/lib/python2.7/site-packages:$PYTHONPATH
export NLTK_DATA=/home/yu.lin/data/nltk_data 

time python final_keyword_s1_1.py   
