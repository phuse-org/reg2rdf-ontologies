# this file changes the combined phrases into two words.
# load the phrase dictionary and switch the key and value

import pickle
import csv,re,os

key_dict_for_result = dict()
with open("/home/yu.lin/21CFR/output/myKeyPhraseDict.txt", "rb") as myFile:
    key_phrase_dict = pickle.load(myFile)
    
    for key in key_phrase_dict.keys():
        key_1 = key.replace(" ","")
        key_dict_for_result[key_1] = key    
m_items = {k: key_dict_for_result[k] for k in key_dict_for_result.keys()[:2]}
print m_items

filename=os.environ['INPUT'] 
file = "/home/yu.lin/21CFR/output/gensim_LDA_out_csv/"+filename
csv_filepath = "/home/yu.lin/21CFR/output/gensim_LDA_out_csv/mapped/"+filename
with open(file) as f:
    reader = csv.DictReader(f)
    for line in reader:
        topic_word = line["Topic Words"]
        if topic_word in key_dict_for_result:
           print key_dict_for_result[topic_word]


