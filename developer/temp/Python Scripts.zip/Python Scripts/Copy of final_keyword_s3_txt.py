#sge_par.sh
#CFR_RAKE_key.lst

import pickle,nltk,re,os

from nltk.stem import WordNetLemmatizer
wnl = WordNetLemmatizer()

stoplist = set(nltk.corpus.stopwords.words("stopwords_CFR")) 

with open("/home/yu.lin/21CFR/output/title_dict.txt", "rb") as myFile_t:
    title_dict = pickle.load(myFile_t)
    
with open("/home/yu.lin/21CFR/output/title_word_bag_list.txt", "rb") as myFile_tw:
    title_word_bag = pickle.load(myFile_tw)

with open("/home/yu.lin/21CFR/output/def_word_bag_list.txt", "rb") as myFile_dw:
    def_word_bag = pickle.load(myFile_dw)


def format(value):
    return "%.5f" % value
    
filename=os.environ['INPUT']
sectionNo = filename.replace(".key","")
with open("/home/yu.lin/21CFR/output/Gensim_score_list/"+sectionNo+"_gensim_score_dict.txt", "rb") as myFile_gs:
    Gensim_score = pickle.load(myFile_gs)
    print Gensim_score
    
openfile = open("/home/yu.lin/21CFR/output/final_key_txt/"+sectionNo+".final_key.txt", "w")

if sectionNo in title_dict.keys():
    title = title_dict[sectionNo]
    openfile.write("Section: "+sectionNo+" "+title.encode("ascii","ignore")+"\n")

    RAKE_file = "/home/yu.lin/21CFR/output/CFR_keywords_RAKE/"+filename

    with open(RAKE_file) as f:    
        all_list = dict()
        for line in f:
            score_set = line.strip().split(",")
            words = score_set[0]
            words = words.decode('utf-8')
            words_set = words.split()
            stem_words_set = []
            score = float(score_set[1])
            print words_set
        
            # match in the Gensim_score dict
            gensim_score_total = 0
            def_score_total = 0
            title_score_total = 0
            final_score = 0
        
            if len(words_set) > 1:
                for eachword in words_set:
                    if (eachword.endswith(('ed','ing')) and eachword <> 'labeling'):
                        eachword = wnl.lemmatize(eachword,'v')
                    else:
                        eachword = wnl.lemmatize(eachword)
                    stem_words_set.append(eachword)
                    
                    reObj = re.compile(eachword)
                    for key in Gensim_score.keys():
                        if(reObj.match(key)):
                            print key, Gensim_score[key]
                                                 
                    if eachword in Gensim_score.keys():
                        gensim_score = float(Gensim_score[eachword])*1000 
                        gensim_score_total += gensim_score
                    
                    if eachword in def_word_bag:
                        def_score = 1
                        def_score_total +=def_score
                
                    if eachword in title_word_bag:
                        title_score = 1
                        title_score_total +=title_score
                
                stem_phrase = " ".join(stem_words_set)
                print stem_phrase
                gensim_score_1 = 0
                if stem_phrase in Gensim_score:
                    gensim_score_1 = float(Gensim_score[stem_phrase])*1000*len(stem_words_set)
                gensim_score_total = gensim_score_total+gensim_score_1
                print "gensim_score:",gensim_score_total
                print "def_score:",def_score_total
                print "title_score:",title_score_total
            
                final_score = gensim_score_total+def_score_total+title_score_total+score
            
            all_list[stem_phrase] = final_score
            
        all_list_sorted = sorted(all_list.items(), key=lambda x: x[1],reverse=True)
            
        for k in range(0,len(all_list_sorted)):
            line = all_list_sorted[k]
            phrase = line[0]
            phrase = phrase.encode("ascii","ignore")
            score = str(format(line[1]))
            
            
            openfile.write(phrase+","+score+"\n")
    openfile.close()
else:
    logfile = open("/home/yu.lin/21CFR/logfile/final_keyword_"+sectionNo+".log","w")
    logfile.write(sectionNo+"not found in title_dict.\n")

    logfile.close()        
